package springboot.springboot;

import java.util.regex.Pattern;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserResources {
	
	 @GetMapping("/{id}")
    public Response hello(@RequestParam String id, @RequestParam String email) {
		 String data = null;
		 Response re=new Response();
		if(id!=null || email !=null) {
			if (isValid(email)) {
				data="email is not valid";
					re.setError(data);
			}
	        else {
	           re.setEmail(email);
			re.setName(id);
	    } }
		else{
			data="id and email are blank";
			re.setError(data);
		}
       
		return re;
    }
	 
	 public static boolean isValid(String email) 
	    { 
	        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
	                            "[a-zA-Z0-9_+&*-]+)*@" + 
	                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
	                            "A-Z]{2,7}$"; 
	                              
	        Pattern pat = Pattern.compile(emailRegex); 
	        if (email == null) 
	            return false; 
	        return pat.matcher(email).matches(); 
	    } 

}
